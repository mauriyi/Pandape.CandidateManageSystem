﻿namespace Web.ViewModels.Error
{
    public class ErrorViewModel
    {
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public bool IsDevelopment { get; set; }
    }
}
